--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Homebrew)
-- Dumped by pg_dump version 15.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: Evgeny
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO "Evgeny";

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: Evgeny
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Feedback; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public."Feedback" (
    id text NOT NULL,
    "userId" text,
    text text NOT NULL,
    email text,
    "pageUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Feedback" OWNER TO "Evgeny";

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO "Evgeny";

--
-- Name: auravant_tokens; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public.auravant_tokens (
    id text NOT NULL,
    "userId" text NOT NULL,
    "accessToken" text NOT NULL,
    "tokenType" text DEFAULT 'Bearer'::text NOT NULL,
    "extensionId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "expiresAt" timestamp(3) without time zone
);


ALTER TABLE public.auravant_tokens OWNER TO "Evgeny";

--
-- Name: chat_sessions; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public.chat_sessions (
    id text NOT NULL,
    "userId" text NOT NULL,
    title text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.chat_sessions OWNER TO "Evgeny";

--
-- Name: equipment; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public.equipment (
    id text NOT NULL,
    "johnDeereId" text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    model text,
    year integer,
    "serialNumber" text,
    "lastLocation" jsonb,
    "lastSeen" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.equipment OWNER TO "Evgeny";

--
-- Name: field_operations; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public.field_operations (
    id text NOT NULL,
    "johnDeereFieldId" text,
    "operationType" text NOT NULL,
    "operationDate" timestamp(3) without time zone NOT NULL,
    "equipmentId" text,
    area double precision,
    yield double precision,
    notes text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "auravantUuid" text,
    "dataSource" text DEFAULT 'johndeere'::text NOT NULL,
    "herdUuid" text,
    "labourTypeId" integer,
    "paddockId" integer,
    status integer,
    "workOrderUuid" text,
    yeargroup integer
);


ALTER TABLE public.field_operations OWNER TO "Evgeny";

--
-- Name: file_uploads; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public.file_uploads (
    id text NOT NULL,
    filename text NOT NULL,
    "originalName" text NOT NULL,
    "fileType" text NOT NULL,
    "fileSize" integer NOT NULL,
    "filePath" text NOT NULL,
    status text DEFAULT 'uploaded'::text NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.file_uploads OWNER TO "Evgeny";

--
-- Name: john_deere_tokens; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public.john_deere_tokens (
    id text NOT NULL,
    "userId" text NOT NULL,
    "accessToken" text NOT NULL,
    "refreshToken" text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    scope text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.john_deere_tokens OWNER TO "Evgeny";

--
-- Name: livestock_herds; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public.livestock_herds (
    id text NOT NULL,
    "userId" text NOT NULL,
    "herdUuid" text NOT NULL,
    "herdName" text NOT NULL,
    "animalCount" integer NOT NULL,
    weight double precision,
    "weightUnit" text DEFAULT 'Kg'::text NOT NULL,
    "typeId" integer NOT NULL,
    "paddockId" integer,
    "fieldId" integer,
    "farmId" integer,
    "dataSource" text DEFAULT 'auravant'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.livestock_herds OWNER TO "Evgeny";

--
-- Name: messages; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public.messages (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    "fileAttachments" jsonb,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.messages OWNER TO "Evgeny";

--
-- Name: satshot_tokens; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public.satshot_tokens (
    id text NOT NULL,
    "userId" text NOT NULL,
    "sessionToken" text NOT NULL,
    username text,
    server text DEFAULT 'us'::text NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "lastUsed" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.satshot_tokens OWNER TO "Evgeny";

--
-- Name: users; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    name text,
    "johnDeereConnected" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    password text,
    "auravantConnected" boolean DEFAULT false NOT NULL,
    "satshotConnected" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO "Evgeny";

--
-- Name: work_orders; Type: TABLE; Schema: public; Owner: Evgeny
--

CREATE TABLE public.work_orders (
    id text NOT NULL,
    "userId" text NOT NULL,
    "workOrderUuid" text NOT NULL,
    name text NOT NULL,
    yeargroup integer NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    notes text,
    status text DEFAULT 'planned'::text NOT NULL,
    recommendations jsonb,
    "labourOperations" text[],
    "dataSource" text DEFAULT 'auravant'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.work_orders OWNER TO "Evgeny";

--
-- Data for Name: Feedback; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public."Feedback" (id, "userId", text, email, "pageUrl", "createdAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
00e9b016-7a47-43a7-87b5-dc77e395a333	3508922f49d25c79341c440844d36a58e503a92e5e25b0dc86e94c0bd783f12f	2025-08-23 19:46:11.789475+02	20250618153618_init	\N	\N	2025-08-23 19:46:11.755352+02	1
29608963-070e-4bae-9b1b-480ea6e476bc	105c5ea2418f0daec568182dbc02dc9523d2c025297613672aa584868cb0873b	2025-08-23 19:46:11.790841+02	20250618195919_add_password_field	\N	\N	2025-08-23 19:46:11.789798+02	1
7fcd7abb-d3ae-4e6a-b29d-466c09d759af	789244910ac3276f11949f0da5e854cb826147aa4705872c34c747ac6cc08928	2025-08-23 19:46:11.798843+02	20250622090015_add_auravant_integration	\N	\N	2025-08-23 19:46:11.791156+02	1
26a5bf7c-9659-4e0c-bb3a-105377b62307	933e2415aeb9d82d06b21d40809ac94494228816dd2a0e09b4d8e6042679af17	2025-08-23 19:46:11.801114+02	20250703115924_add_feedback	\N	\N	2025-08-23 19:46:11.799111+02	1
32fb53c7-5c56-4313-86dc-97265bdd4918	f3244128463a8d4b837657b0fa3ddd4c5ece2e490ac54f6ec1b6093aa4cac0c8	2025-08-23 19:46:28.536696+02	20250823174628_add_satshot_integration	\N	\N	2025-08-23 19:46:28.531161+02	1
\.


--
-- Data for Name: auravant_tokens; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public.auravant_tokens (id, "userId", "accessToken", "tokenType", "extensionId", "createdAt", "updatedAt", "expiresAt") FROM stdin;
\.


--
-- Data for Name: chat_sessions; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public.chat_sessions (id, "userId", title, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public.equipment (id, "johnDeereId", name, type, model, year, "serialNumber", "lastLocation", "lastSeen", "isActive", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: field_operations; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public.field_operations (id, "johnDeereFieldId", "operationType", "operationDate", "equipmentId", area, yield, notes, metadata, "createdAt", "auravantUuid", "dataSource", "herdUuid", "labourTypeId", "paddockId", status, "workOrderUuid", yeargroup) FROM stdin;
\.


--
-- Data for Name: file_uploads; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public.file_uploads (id, filename, "originalName", "fileType", "fileSize", "filePath", status, metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: john_deere_tokens; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public.john_deere_tokens (id, "userId", "accessToken", "refreshToken", "expiresAt", scope, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: livestock_herds; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public.livestock_herds (id, "userId", "herdUuid", "herdName", "animalCount", weight, "weightUnit", "typeId", "paddockId", "fieldId", "farmId", "dataSource", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public.messages (id, "sessionId", role, content, "fileAttachments", metadata, "createdAt") FROM stdin;
\.


--
-- Data for Name: satshot_tokens; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public.satshot_tokens (id, "userId", "sessionToken", username, server, "expiresAt", "lastUsed", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public.users (id, email, name, "johnDeereConnected", "createdAt", "updatedAt", password, "auravantConnected", "satshotConnected") FROM stdin;
cmeok1ra90000l5tafto4fimw	evs.abyss@gmail.com	evs.abyss	f	2025-08-23 17:50:25.377	2025-08-23 17:50:25.377	$2b$10$1v0gWJccTpaoRaMFUGFn3.r5dHtkeEbwN271vSq8JOnaY.r5GdA4C	f	f
\.


--
-- Data for Name: work_orders; Type: TABLE DATA; Schema: public; Owner: Evgeny
--

COPY public.work_orders (id, "userId", "workOrderUuid", name, yeargroup, date, notes, status, recommendations, "labourOperations", "dataSource", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: Feedback Feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public."Feedback"
    ADD CONSTRAINT "Feedback_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: auravant_tokens auravant_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.auravant_tokens
    ADD CONSTRAINT auravant_tokens_pkey PRIMARY KEY (id);


--
-- Name: chat_sessions chat_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT chat_sessions_pkey PRIMARY KEY (id);


--
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (id);


--
-- Name: field_operations field_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.field_operations
    ADD CONSTRAINT field_operations_pkey PRIMARY KEY (id);


--
-- Name: file_uploads file_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.file_uploads
    ADD CONSTRAINT file_uploads_pkey PRIMARY KEY (id);


--
-- Name: john_deere_tokens john_deere_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.john_deere_tokens
    ADD CONSTRAINT john_deere_tokens_pkey PRIMARY KEY (id);


--
-- Name: livestock_herds livestock_herds_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.livestock_herds
    ADD CONSTRAINT livestock_herds_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: satshot_tokens satshot_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.satshot_tokens
    ADD CONSTRAINT satshot_tokens_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: work_orders work_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_pkey PRIMARY KEY (id);


--
-- Name: auravant_tokens_userId_key; Type: INDEX; Schema: public; Owner: Evgeny
--

CREATE UNIQUE INDEX "auravant_tokens_userId_key" ON public.auravant_tokens USING btree ("userId");


--
-- Name: chat_sessions_userId_idx; Type: INDEX; Schema: public; Owner: Evgeny
--

CREATE INDEX "chat_sessions_userId_idx" ON public.chat_sessions USING btree ("userId");


--
-- Name: equipment_johnDeereId_key; Type: INDEX; Schema: public; Owner: Evgeny
--

CREATE UNIQUE INDEX "equipment_johnDeereId_key" ON public.equipment USING btree ("johnDeereId");


--
-- Name: john_deere_tokens_userId_key; Type: INDEX; Schema: public; Owner: Evgeny
--

CREATE UNIQUE INDEX "john_deere_tokens_userId_key" ON public.john_deere_tokens USING btree ("userId");


--
-- Name: livestock_herds_herdUuid_key; Type: INDEX; Schema: public; Owner: Evgeny
--

CREATE UNIQUE INDEX "livestock_herds_herdUuid_key" ON public.livestock_herds USING btree ("herdUuid");


--
-- Name: messages_sessionId_createdAt_idx; Type: INDEX; Schema: public; Owner: Evgeny
--

CREATE INDEX "messages_sessionId_createdAt_idx" ON public.messages USING btree ("sessionId", "createdAt");


--
-- Name: messages_sessionId_idx; Type: INDEX; Schema: public; Owner: Evgeny
--

CREATE INDEX "messages_sessionId_idx" ON public.messages USING btree ("sessionId");


--
-- Name: satshot_tokens_userId_key; Type: INDEX; Schema: public; Owner: Evgeny
--

CREATE UNIQUE INDEX "satshot_tokens_userId_key" ON public.satshot_tokens USING btree ("userId");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: Evgeny
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: work_orders_workOrderUuid_key; Type: INDEX; Schema: public; Owner: Evgeny
--

CREATE UNIQUE INDEX "work_orders_workOrderUuid_key" ON public.work_orders USING btree ("workOrderUuid");


--
-- Name: auravant_tokens auravant_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.auravant_tokens
    ADD CONSTRAINT "auravant_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chat_sessions chat_sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.chat_sessions
    ADD CONSTRAINT "chat_sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: john_deere_tokens john_deere_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.john_deere_tokens
    ADD CONSTRAINT "john_deere_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: livestock_herds livestock_herds_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.livestock_herds
    ADD CONSTRAINT "livestock_herds_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: messages messages_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT "messages_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.chat_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: satshot_tokens satshot_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.satshot_tokens
    ADD CONSTRAINT "satshot_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: work_orders work_orders_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: Evgeny
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT "work_orders_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: Evgeny
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

